num1 = input("Enter a Number: ")
num2 = input("Enter your next Number: ")
result = float(num1) + float(num2)

print(result)
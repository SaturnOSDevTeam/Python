
name = input("Input your name:")
career_path = input("Input your career path:")
step_1 = input("Input your first step on how to get there:")
step_2 = input("Input your second step on how to get there:")
step_3 = input("Input your third step on how to get there:")

print("I am " + name)
print("My Career Path Is a" + career_path)
print("My 1st Step is:" + step_1)
print("My 2nd Step is:" + step_2)
print("My 2nd Step is:" + step_3)
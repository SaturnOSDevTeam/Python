
color = input("Input a color:")
plural_noun = input("Input a plural noun:")
celebrity = input("Input a celebrity:")

print("Roses are " + color)
print(plural_noun + " are blue")
print("I love" + celebrity)
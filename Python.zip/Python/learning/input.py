
name = input("Enter Your Name:")
age = input("Enter Your Age:")
print("Hello " + name + "! You Are " + age + "!")
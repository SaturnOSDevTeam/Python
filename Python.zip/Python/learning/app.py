
character_name = "Tom"
character_age = "50"
is_male = True
print("There onece was a man named " + character_name +",")
print("he was "+ character_age +" years old.")

character_name = "George"
print("he really liked the name " + character_name +".")
print("but didn't like being " + character_age +".")
phrase = "BearLotus"
print(phrase.replace("Lotus","Man"))

lucky_numbers = [4, 8, 15, 16, 23, 42]
friends = ["Omar", "James", "Borhan" ,"Nic", "Ali"]

print(friends)
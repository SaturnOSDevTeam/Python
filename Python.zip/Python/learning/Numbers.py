from math import *

my_num = -5  
print(floor(6.9))
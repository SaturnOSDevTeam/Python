
friends = ["Omar", "James", "Borhan" ,"Nic", "Ali"]
friends [1] = "Mike"
print(friends[1:4])